<?php

namespace core;

class RoleUtils {

    public static function addRole($role) {
        if (!in_array($role, App::getConf()->roles)) {
            App::getConf()->roles[] = $role;
            $_SESSION['_amelia_roles'] = serialize(App::getConf()->roles);
        }
    }

    public static function removeRole($role) {
        $key = array_search($role, App::getConf()->roles);
        if ($key !== false) {
            unset(App::getConf()->roles[$key]);
            $_SESSION['_amelia_roles'] = serialize(App::getConf()->roles);
        }
    }

    public static function inRole($role) {
        return in_array($role, App::getConf()->roles);
    }

    public static function getRoles() {
        return App::getConf()->roles;
    }

    public static function clearRoles() {
        App::getConf()->roles = array();
        $_SESSION['_amelia_roles'] = serialize(array());
    }

}