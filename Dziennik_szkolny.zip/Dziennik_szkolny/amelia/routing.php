<?php

use core\App;
use core\Utils;

App::getRouter()->setDefaultRoute('login');
App::getRouter()->setLoginRoute('login');

Utils::addRoute('login', 'LoginController');
Utils::addRoute('logout', 'LoginController');

Utils::addRoute('adminPanel', 'AdminPanelCtrl', ['Admin']);
Utils::addRoute('adminAddUser', 'AdminPanelCtrl', ['Admin']);
Utils::addRoute('adminEditUser', 'AdminPanelCtrl', ['Admin']);
Utils::addRoute('adminDeleteUser', 'AdminPanelCtrl', ['Admin']);
Utils::addRoute('adminGetUser', 'AdminPanelCtrl', ['Admin']);

Utils::addRoute('teacherPanel', 'TeacherPanelCtrl', ['Nauczyciel']);
Utils::addRoute('studentPanel', 'StudentPanelCtrl', ['Uczen']);
Utils::addRoute('getGradesAjax', 'StudentPanelCtrl', ['Uczen']);

Utils::addRoute('userList', 'UserListCtrl');
Utils::addRoute('hello', 'HelloCtrl');