<?php
require_once '../init.php';
use core\App;

$action = $_REQUEST['action'] ?? null;
if ($action) {
    App::getRouter()->setAction($action);
}

include App::getConf()->root_path . App::getConf()->action_script;