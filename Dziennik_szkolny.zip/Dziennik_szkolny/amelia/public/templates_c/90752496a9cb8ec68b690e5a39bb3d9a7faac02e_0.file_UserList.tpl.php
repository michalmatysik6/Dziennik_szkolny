<?php
/* Smarty version 5.4.5, created on 2026-05-03 22:22:57
  from 'file:UserList.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.5',
  'unifunc' => 'content_69f7aea16a0372_60477045',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '90752496a9cb8ec68b690e5a39bb3d9a7faac02e' => 
    array (
      0 => 'UserList.tpl',
      1 => 1777839768,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_69f7aea16a0372_60477045 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\html5up-editorial\\amelia\\app\\views';
?><!DOCTYPE HTML>
<html>
<head>
    <title>Lista użytkowników</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="<?php echo $_smarty_tpl->getValue('conf')->app_root;?>
/assets/css/main.css" />
</head>
<body class="is-preload">

<div id="wrapper">
    <div id="main">
        <div class="inner">
            
            <header id="header">
                <a href="#" class="logo"><strong>Dziennik szkolny</strong> - lista użytkowników</a>
            </header>
            
            <section>
                <header class="main">
                    <h1>Użytkownicy systemu</h1>
                </header>
                
                <div class="table-wrapper">
                    <table class="alt">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Login</th>
                                <th>Imię</th>
                                <th>Nazwisko</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Aktywny</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('users'), 'u');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('u')->value) {
$foreach0DoElse = false;
?>
                            <tr>
                                <td><?php echo $_smarty_tpl->getValue('u')['id_uzytkownik'];?>
</td>
                                <td><?php echo $_smarty_tpl->getValue('u')['login'];?>
</td>
                                <td><?php echo $_smarty_tpl->getValue('u')['imie'];?>
</td>
                                <td><?php echo $_smarty_tpl->getValue('u')['nazwisko'];?>
</td>
                                <td><?php echo $_smarty_tpl->getValue('u')['email'];?>
</td>
                                <td><?php echo (($tmp = $_smarty_tpl->getValue('u')['role'] ?? null)===null||$tmp==='' ? 'brak' ?? null : $tmp);?>
</td>
                                <td><?php if ($_smarty_tpl->getValue('u')['aktywny']) {?>Tak<?php } else { ?>Nie<?php }?></td>
                            </tr>
                            <?php
}
if ($foreach0DoElse) {
?>
                            <tr>
                                <td colspan="7">Brak użytkowników w bazie</td>
                            </tr>
                            <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
                        </tbody>
                    </table>
                </div>
                
            </section>
            
        </div>
    </div>
</div>

<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->getValue('conf')->app_root;?>
/assets/js/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->getValue('conf')->app_root;?>
/assets/js/browser.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->getValue('conf')->app_root;?>
/assets/js/breakpoints.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->getValue('conf')->app_root;?>
/assets/js/util.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->getValue('conf')->app_root;?>
/assets/js/main.js"><?php echo '</script'; ?>
>

</body>
</html><?php }
}
