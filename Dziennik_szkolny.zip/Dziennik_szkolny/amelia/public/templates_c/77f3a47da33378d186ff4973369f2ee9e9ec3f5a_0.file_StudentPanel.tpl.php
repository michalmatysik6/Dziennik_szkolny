<?php
/* Smarty version 5.4.5, created on 2026-05-15 14:49:53
  from 'file:StudentPanel.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.5',
  'unifunc' => 'content_6a071671225961_94479506',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '77f3a47da33378d186ff4973369f2ee9e9ec3f5a' => 
    array (
      0 => 'StudentPanel.tpl',
      1 => 1778849104,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_6a071671225961_94479506 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\Dziennik_szkolny\\amelia\\app\\views';
?><!DOCTYPE HTML>
<html>
<head>
    <title>Panel Ucznia - Dziennik szkolny</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="http://localhost/Dziennik_szkolny/assets/css/main.css" />
</head>
<body class="is-preload">

<div id="wrapper">
    <div id="sidebar">
        <div class="inner">
            <nav id="menu">
                <header class="major">
                    <h2>Przedmioty</h2>
                </header>
                <ul id="subjects-list">
                    <li><a href="#" data-subject-id="" class="subject-link">Wybierz przedmiot</a></li>
                    <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('subjects'), 's');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('s')->value) {
$foreach0DoElse = false;
?>
                    <li>
                        <a href="#" data-subject-id="<?php echo $_smarty_tpl->getValue('s')['id_przedmiot'];?>
" data-subject-name="<?php echo $_smarty_tpl->getValue('s')['nazwa'];?>
" class="subject-link">
                            <?php echo $_smarty_tpl->getValue('s')['nazwa'];?>

                        </a>
                    </li>
                    <?php
}
if ($foreach0DoElse) {
?>
                    <li><a href="#">Brak przedmiotów</a></li>
                    <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
                </ul>
            </nav>
            
            <section>
                <header class="major">
                    <h2>Informacje o profilu</h2>
                </header>
                <div class="mini-posts">
                    <article>
                        <p><strong>Rola:</strong> <?php echo $_smarty_tpl->getValue('user_role_display');?>
</p>
                        <p><strong>Imię i nazwisko:</strong> <?php echo $_smarty_tpl->getValue('user_name');?>
</p>
                        <p><strong>Email:</strong> <?php echo $_smarty_tpl->getValue('user_email');?>
</p>
                        <p><strong>Klasa:</strong> <?php echo $_smarty_tpl->getValue('class_name');?>
</p>
                        <p><strong>Wychowawca:</strong> <?php echo $_smarty_tpl->getValue('homeroom_teacher');?>
</p>
                    </article>
                </div>
            </section>
            
            <footer id="footer">
                <p>Zalogowany jako: <?php echo $_smarty_tpl->getValue('user_name');?>
</p>
                <a href="http://localhost/Dziennik_szkolny/amelia/public/index.php?action=logout" class="button primary fit">Wyloguj się</a>
            </footer>
        </div>
    </div>

    <div id="main">
        <div class="inner">
            <header id="header">
                <a href="#" class="logo"><strong>Dziennik szkolny</strong> - Panel Ucznia</a>
            </header>
            
            <section>
                <header class="main">
                    <h1>Moje oceny</h1>
                </header>
                
                <div id="grades-container">
                    <div class="box">
                        <p><strong>To jest dziennik ocen.</strong> Aby zobaczyć oceny, wybierz przedmiot z panelu po lewej stronie.</p>
                    </div>
                </div>
                
            </section>
        </div>
    </div>
</div>

<?php echo '<script'; ?>
 src="http://localhost/Dziennik_szkolny/assets/js/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="http://localhost/Dziennik_szkolny/assets/js/browser.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="http://localhost/Dziennik_szkolny/assets/js/breakpoints.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="http://localhost/Dziennik_szkolny/assets/js/util.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="http://localhost/Dziennik_szkolny/assets/js/main.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
>
document.addEventListener('DOMContentLoaded', function() {
    var subjectLinks = document.querySelectorAll('.subject-link');
    var gradesContainer = document.getElementById('grades-container');
    var actionUrl = 'http://localhost/Dziennik_szkolny/amelia/public/index.php?action=getGradesAjax&subject_id=';
    var sidebar = document.getElementById('sidebar');
    
    function hideSidebarOnMobile() {
        if (window.innerWidth <= 1280) {
            if (sidebar && !sidebar.classList.contains('inactive')) {
                sidebar.classList.add('inactive');
            }
        }
    }
    
    function loadGrades(subjectId, subjectName) {
        if (!subjectId) {
            gradesContainer.innerHTML = '<div class="box"><p><strong>To jest dziennik ocen.</strong> Aby zobaczyć oceny, wybierz przedmiot z panelu po lewej stronie.</p></div>';
            return;
        }
        
        gradesContainer.innerHTML = '<div class="box"><p>Ładowanie ocen...</p></div>';
        
        fetch(actionUrl + subjectId)
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                if (data.error) {
                    gradesContainer.innerHTML = '<div class="box"><p>' + data.error + '</p></div>';
                    return;
                }
                
                var gradesHtml = '<h3>Przedmiot: ' + data.subject_name + '</h3>';
                gradesHtml += '<div class="table-wrapper">';
                gradesHtml += '<table class="alt">';
                gradesHtml += '<thead>';
                gradesHtml += '<tr>';
                gradesHtml += '<th>Ocena</th>';
                gradesHtml += '<th>Waga</th>';
                gradesHtml += '<th>Data wystawienia</th>';
                gradesHtml += '<th>Nauczyciel</th>';
                gradesHtml += '<th>Opis</th>';
                gradesHtml += '</tr>';
                gradesHtml += '</thead>';
                gradesHtml += '<tbody>';
                
                if (data.grades.length === 0) {
                    gradesHtml += '<tr>';
                    gradesHtml += '<td colspan="5">Brak ocen z tego przedmiotu</td>';
                    gradesHtml += '</tr>';
                } else {
                    for (var i = 0; i < data.grades.length; i++) {
                        var grade = data.grades[i];
                        gradesHtml += '<tr>';
                        gradesHtml += '<td><strong>' + grade.wartosc + '</strong></td>';
                        gradesHtml += '<td>' + grade.waga + '</td>';
                        gradesHtml += '<td>' + grade.data_wystawienia + '</td>';
                        gradesHtml += '<td>' + grade.nauczyciel + '</td>';
                        gradesHtml += '<td>' + (grade.opis || '-') + '</td>';
                        gradesHtml += '</tr>';
                    }
                }
                
                gradesHtml += '</tbody>';
                gradesHtml += '</table>';
                gradesHtml += '</div>';
                
                if (data.arithmetic_average || data.weighted_average) {
                    gradesHtml += '<div style="background-color: #e8f5e9; border: 1px solid #4caf50; border-radius: 8px; padding: 1.5em; margin-top: 2em;">';
                    gradesHtml += '<h3 style="margin-top: 0; color: #2e7d32;">Podsumowanie</h3>';
                    gradesHtml += '<p><strong>Średnia arytmetyczna:</strong> ' + data.arithmetic_average + '</p>';
                    gradesHtml += '<p><strong>Średnia ważona:</strong> ' + data.weighted_average + '</p>';
                    gradesHtml += '</div>';
                }
                
                gradesContainer.innerHTML = gradesHtml;
                
                hideSidebarOnMobile();
            })
            .catch(function(error) {
                gradesContainer.innerHTML = '<div class="box"><p>Wystąpił błąd podczas ładowania ocen.</p></div>';
                console.error('Error:', error);
            });
    }
    
    for (var i = 0; i < subjectLinks.length; i++) {
        var link = subjectLinks[i];
        link.addEventListener('click', function(e) {
            e.preventDefault();
            var subjectId = this.getAttribute('data-subject-id');
            var subjectName = this.textContent;
            
            for (var j = 0; j < subjectLinks.length; j++) {
                subjectLinks[j].classList.remove('active');
            }
            this.classList.add('active');
            
            loadGrades(subjectId, subjectName);
        });
    }
});
<?php echo '</script'; ?>
>

</body>
</html><?php }
}
