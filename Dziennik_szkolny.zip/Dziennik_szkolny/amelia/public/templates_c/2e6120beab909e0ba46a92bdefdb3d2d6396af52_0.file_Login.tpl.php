<?php
/* Smarty version 5.4.5, created on 2026-05-07 08:38:40
  from 'file:Login.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.5',
  'unifunc' => 'content_69fc3370baf048_75037113',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2e6120beab909e0ba46a92bdefdb3d2d6396af52' => 
    array (
      0 => 'Login.tpl',
      1 => 1778135882,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_69fc3370baf048_75037113 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\html5up-editorial\\amelia\\app\\views';
?><!DOCTYPE HTML>
<html>
<head>
    <title>Logowanie - Dziennik szkolny</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="http://localhost/html5up-editorial/assets/css/main.css" />
</head>
<body class="is-preload">

<div id="wrapper">
    <div id="main">
        <div class="inner">
            
            <header id="header">
                <a href="#" class="logo"><strong>Dziennik szkolny</strong> - logowanie</a>
            </header>
            
            <section>
                <header class="main">
                    <h1>Zaloguj się</h1>
                </header>
                
                <?php if ($_smarty_tpl->getValue('msgs')->isError()) {?>
                <div class="box" style="background-color: #faa; border-color: #f00;">
                    <h3>Wystąpiły błędy:</h3>
                    <ul>
                        <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('msgs')->getMessages(), 'msg');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('msg')->value) {
$foreach0DoElse = false;
?>
                            <?php if ($_smarty_tpl->getValue('msg')->isError()) {?>
                                <li><?php echo $_smarty_tpl->getValue('msg')->text;?>
</li>
                            <?php }?>
                        <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
                    </ul>
                </div>
                <?php }?>
                
                <?php if ($_smarty_tpl->getValue('msgs')->isInfo()) {?>
                <div class="box" style="background-color: #afa; border-color: #0a0;">
                    <h3>Informacje:</h3>
                    <ul>
                        <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('msgs')->getMessages(), 'msg');
$foreach1DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('msg')->value) {
$foreach1DoElse = false;
?>
                            <?php if ($_smarty_tpl->getValue('msg')->isInfo()) {?>
                                <li><?php echo $_smarty_tpl->getValue('msg')->text;?>
</li>
                            <?php }?>
                        <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
                    </ul>
                </div>
                <?php }?>
                
                <form method="post" action="http://localhost/html5up-editorial/amelia/public/index.php?action=login">
                    <div class="row gtr-uniform">
                        <div class="col-12">
                            <input type="text" name="login" id="login" value="<?php echo (($tmp = $_smarty_tpl->getValue('form')['login'] ?? null)===null||$tmp==='' ? '' ?? null : $tmp);?>
" placeholder="Login" />
                        </div>
                        <div class="col-12">
                            <input type="password" name="pass" id="pass" placeholder="Hasło" />
                        </div>
                        <div class="col-12">
                            <ul class="actions">
                                <li><input type="submit" value="Zaloguj" class="primary" /></li>
                            </ul>
                        </div>
                    </div>
                </form>
                
            </section>
            
        </div>
    </div>
</div>

<?php echo '<script'; ?>
 src="http://localhost/html5up-editorial/assets/js/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="http://localhost/html5up-editorial/assets/js/browser.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="http://localhost/html5up-editorial/assets/js/breakpoints.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="http://localhost/html5up-editorial/assets/js/util.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="http://localhost/html5up-editorial/assets/js/main.js"><?php echo '</script'; ?>
>

</body>
</html><?php }
}
