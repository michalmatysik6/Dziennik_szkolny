<?php
/* Smarty version 5.4.5, created on 2026-05-15 14:49:01
  from 'file:TeacherPanel.tpl' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.5',
  'unifunc' => 'content_6a07163deeb6d3_45021326',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '082e36b875ed182a60c5fda2ce38c0ed3ee82cdb' => 
    array (
      0 => 'TeacherPanel.tpl',
      1 => 1778849246,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_6a07163deeb6d3_45021326 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\Dziennik_szkolny\\amelia\\app\\views';
?><!DOCTYPE HTML>
<html>
<head>
    <title>Panel Nauczyciela - Dziennik szkolny</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="http://localhost/Dziennik_szkolny/assets/css/main.css" />
    <style>
        .student-list {
            margin-top: 20px;
        }
        .student-item {
            background: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
        }
        .grades-list {
            margin-top: 15px;
            padding-left: 20px;
            border-left: 3px solid #f56a6a;
        }
        .grade-item {
            padding: 10px;
            margin: 5px 0;
            background: #f9f9f9;
            border-radius: 4px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .sort-buttons {
            margin-bottom: 15px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .sort-buttons button {
            padding: 5px 10px;
            font-size: 12px;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 20000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: #fff;
            margin: 5% auto;
            padding: 20px;
            width: 50%;
            max-width: 500px;
            border-radius: 8px;
        }
        .close {
            float: right;
            font-size: 28px;
            cursor: pointer;
        }
        .btn-small {
            padding: 4px 8px;
            font-size: 12px;
            margin: 2px;
            background-color: #f5f6f7;
            border: 1px solid #ddd;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-small:hover {
            background-color: #e6e6e6;
        }
    </style>
</head>
<body class="is-preload">

<div id="wrapper">
    <div id="sidebar">
        <div class="inner">
            <nav id="menu">
                <header class="major">
                    <h2>Przedmioty</h2>
                </header>
                <ul id="subjects-list">
                    <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('subjects'), 's');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('s')->value) {
$foreach0DoElse = false;
?>
                    <li>
                        <a href="#" data-subject-id="<?php echo $_smarty_tpl->getValue('s')['id_przedmiot'];?>
" data-subject-name="<?php echo $_smarty_tpl->getValue('s')['nazwa'];?>
" class="subject-link">
                            <?php echo $_smarty_tpl->getValue('s')['nazwa'];?>

                        </a>
                    </li>
                    <?php
}
if ($foreach0DoElse) {
?>
                    <li><a href="#">Brak przypisanych przedmiotów</a></li>
                    <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
                </ul>
            </nav>
            
            <section>
                <header class="major">
                    <h2>Informacje</h2>
                </header>
                <div class="mini-posts">
                    <article>
                        <p><strong>Zalogowany:</strong> <?php echo $_smarty_tpl->getValue('user_name');?>
</p>
                        <p><strong>Rola:</strong> Nauczyciel</p>
                    </article>
                </div>
            </section>
            
            <footer id="footer">
                <a href="http://localhost/Dziennik_szkolny/amelia/public/index.php?action=logout" class="button primary fit">Wyloguj się</a>
            </footer>
        </div>
    </div>

    <div id="main">
        <div class="inner">
            <header id="header">
                <a href="#" class="logo"><strong>Dziennik szkolny</strong> - Panel Nauczyciela</a>
            </header>
            
            <section>
                <header class="main">
                    <h1>Wystawianie ocen</h1>
                </header>
                
                <div id="students-container">
                    <div class="box">
                        <p>Wybierz przedmiot z panelu po lewej stronie, aby zobaczyć listę uczniów.</p>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<div id="gradeModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3 id="modalTitle">Dodaj ocenę</h3>
        <form id="gradeForm">
            <input type="hidden" name="grade_id" id="gradeId">
            <input type="hidden" name="subject_id" id="gradeSubjectId">
            <input type="hidden" name="student_id" id="gradeStudentId">
            
            <div class="row gtr-uniform">
                <div class="col-12">
                    <label>Ocena (1-6) *</label>
                    <input type="number" step="0.5" name="wartosc" id="wartosc" min="1" max="6" required>
                </div>
                <div class="col-12">
                    <label>Waga (1-10) *</label>
                    <input type="number" name="waga" id="waga" min="1" max="10" value="1" required>
                </div>
                <div class="col-12">
                    <label>Data wystawienia *</label>
                    <input type="date" name="data_wystawienia" id="data_wystawienia" required>
                </div>
                <div class="col-12">
                    <label>Opis</label>
                    <textarea name="opis" id="opis" rows="3" placeholder="Np. Kartkówka, Sprawdzian, Odpowiedź ustna..."></textarea>
                </div>
                <div class="col-12">
                    <ul class="actions">
                        <li><input type="submit" value="Zapisz" class="primary"></li>
                        <li><button type="button" class="closeModalBtn">Anuluj</button></li>
                    </ul>
                </div>
            </div>
        </form>
    </div>
</div>

<?php echo '<script'; ?>
 src="http://localhost/Dziennik_szkolny/assets/js/jquery.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="http://localhost/Dziennik_szkolny/assets/js/browser.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="http://localhost/Dziennik_szkolny/assets/js/breakpoints.min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="http://localhost/Dziennik_szkolny/assets/js/util.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 src="http://localhost/Dziennik_szkolny/assets/js/main.js"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
>
document.addEventListener('DOMContentLoaded', function() {
    var subjectLinks = document.querySelectorAll('.subject-link');
    var studentsContainer = document.getElementById('students-container');
    var modal = document.getElementById('gradeModal');
    var span = document.getElementsByClassName('close')[0];
    var closeModalBtns = document.getElementsByClassName('closeModalBtn');
    
    var currentSubjectId = null;
    var currentSubjectName = null;
    var currentSort = 'date_desc';
    
    function closeModal() {
        modal.style.display = 'none';
        document.getElementById('gradeForm').reset();
        document.getElementById('gradeId').value = '';
        document.getElementById('modalTitle').innerHTML = 'Dodaj ocenę';
        document.getElementById('data_wystawienia').value = new Date().toISOString().slice(0,10);
    }
    
    function openAddModal(subjectId, studentId, studentName) {
        document.getElementById('gradeId').value = '';
        document.getElementById('gradeSubjectId').value = subjectId;
        document.getElementById('gradeStudentId').value = studentId;
        document.getElementById('modalTitle').innerHTML = 'Dodaj ocenę dla ucznia: ' + studentName;
        document.getElementById('wartosc').value = '';
        document.getElementById('waga').value = '1';
        document.getElementById('opis').value = '';
        document.getElementById('data_wystawienia').value = new Date().toISOString().slice(0,10);
        modal.style.display = 'block';
    }
    
    function openEditModal(gradeId, studentName) {
        fetch('http://localhost/Dziennik_szkolny/amelia/public/index.php?action=teacherPanel&subaction=getGrade&grade_id=' + gradeId)
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                if (data.error) {
                    alert(data.error);
                    return;
                }
                
                document.getElementById('gradeId').value = data.grade.id_ocena;
                document.getElementById('gradeSubjectId').value = data.grade.id_przedmiot;
                document.getElementById('gradeStudentId').value = data.grade.id_uczen;
                document.getElementById('modalTitle').innerHTML = 'Edytuj ocenę dla ucznia: ' + studentName;
                document.getElementById('wartosc').value = data.grade.wartosc;
                document.getElementById('waga').value = data.grade.waga;
                document.getElementById('opis').value = data.grade.opis || '';
                document.getElementById('data_wystawienia').value = data.grade.data_wystawienia;
                modal.style.display = 'block';
            })
            .catch(function(error) {
                alert('Błąd: ' + error);
            });
    }
    
    if (span) span.onclick = closeModal;
    for (var i = 0; i < closeModalBtns.length; i++) {
        closeModalBtns[i].onclick = closeModal;
    }
    window.onclick = function(event) {
        if (event.target == modal) {
            closeModal();
        }
    }
    
    function loadGrades(studentId, studentName) {
        fetch('http://localhost/Dziennik_szkolny/amelia/public/index.php?action=teacherPanel&subaction=getGrades&subject_id=' + currentSubjectId + '&student_id=' + studentId + '&sort=' + currentSort)
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                if (data.error) {
                    console.error(data.error);
                    return;
                }
                
                var gradesHtml = '<div class="grades-list">';
                gradesHtml += '<div class="sort-buttons">';
                gradesHtml += '<button class="sort-btn" data-sort="date_desc">Najnowsze</button>';
                gradesHtml += '<button class="sort-btn" data-sort="date_asc">Najstarsze</button>';
                gradesHtml += '<button class="sort-btn" data-sort="value_desc">Od najwyższej</button>';
                gradesHtml += '<button class="sort-btn" data-sort="value_asc">Od najniższej</button>';
                gradesHtml += '<button class="sort-btn" data-sort="weight_desc">Waga malejąco</button>';
                gradesHtml += '<button class="sort-btn" data-sort="weight_asc">Waga rosnąco</button>';
                gradesHtml += '</div>';
                gradesHtml += '<h4>Dotychczasowe oceny:</h4>';
                
                if (data.grades.length === 0) {
                    gradesHtml += '<p>Brak ocen</p>';
                } else {
                    for (var i = 0; i < data.grades.length; i++) {
                        var g = data.grades[i];
                        gradesHtml += '<div class="grade-item" data-grade-id="' + g.id_ocena + '">';
                        gradesHtml += '<div class="grade-info">';
                        gradesHtml += '<strong>' + g.wartosc + '</strong> (waga: ' + g.waga + ') - ';
                        gradesHtml += g.data_wystawienia + ' - ' + (g.opis || 'brak opisu');
                        gradesHtml += '</div>';
                        gradesHtml += '<div class="grade-actions">';
                        gradesHtml += '<button class="button small btn-small edit-grade-btn">Edytuj</button>';
                        gradesHtml += '<button class="button small btn-small delete-grade-btn">Usuń</button>';
                        gradesHtml += '</div>';
                        gradesHtml += '</div>';
                    }
                }
                gradesHtml += '<button class="button small" onclick="window.showAddGradeModal(' + studentId + ', \'' + studentName.replace(/'/g, "\\'") + '\')">+ Dodaj ocenę</button>';
                gradesHtml += '</div>';
                
                var studentElement = document.querySelector('.student-item[data-student-id="' + studentId + '"] .grades-container');
                if (studentElement) {
                    studentElement.innerHTML = gradesHtml;
                    
                    var sortBtns = studentElement.querySelectorAll('.sort-btn');
                    for (var j = 0; j < sortBtns.length; j++) {
                        sortBtns[j].addEventListener('click', function(e) {
                            var newSort = this.getAttribute('data-sort');
                            currentSort = newSort;
                            loadGrades(studentId, studentName);
                        });
                    }
                    
                    var editBtns = studentElement.querySelectorAll('.edit-grade-btn');
                    for (var j = 0; j < editBtns.length; j++) {
                        editBtns[j].addEventListener('click', function(e) {
                            e.stopPropagation();
                            var gradeItem = this.closest('.grade-item');
                            var gradeId = gradeItem.getAttribute('data-grade-id');
                            openEditModal(gradeId, studentName);
                        });
                    }
                    
                    var deleteBtns = studentElement.querySelectorAll('.delete-grade-btn');
                    for (var j = 0; j < deleteBtns.length; j++) {
                        deleteBtns[j].addEventListener('click', function(e) {
                            e.stopPropagation();
                            var gradeItem = this.closest('.grade-item');
                            var gradeId = gradeItem.getAttribute('data-grade-id');
                            
                            if (confirm('Czy na pewno chcesz usunąć tę ocenę?')) {
                                var formData = new FormData();
                                formData.append('grade_id', gradeId);
                                
                                fetch('http://localhost/Dziennik_szkolny/amelia/public/index.php?action=teacherPanel&subaction=deleteGrade', {
                                    method: 'POST',
                                    body: formData
                                })
                                .then(function(response) {
                                    return response.json();
                                })
                                .then(function(data) {
                                    if (data.error) {
                                        alert(data.error);
                                    } else if (data.success) {
                                        alert(data.message);
                                        loadGrades(studentId, studentName);
                                    }
                                })
                                .catch(function(error) {
                                    alert('Błąd: ' + error);
                                });
                            }
                        });
                    }
                }
            })
            .catch(function(error) {
                console.error('Error loading grades:', error);
            });
    }
    
    window.showAddGradeModal = function(studentId, studentName) {
        openAddModal(currentSubjectId, studentId, studentName);
    }
    
    function loadStudents(subjectId, subjectName) {
        currentSubjectId = subjectId;
        currentSubjectName = subjectName;
        currentSort = 'date_desc';
        
        studentsContainer.innerHTML = '<div class="box"><p>Ładowanie uczniów...</p></div>';
        
        fetch('http://localhost/Dziennik_szkolny/amelia/public/index.php?action=teacherPanel&subaction=getStudents&subject_id=' + subjectId)
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                if (data.error) {
                    studentsContainer.innerHTML = '<div class="box"><p>' + data.error + '</p></div>';
                    return;
                }
                
                if (data.students.length === 0) {
                    studentsContainer.innerHTML = '<div class="box"><p>Brak uczniów dla tego przedmiotu.</p></div>';
                    return;
                }
                
                var studentsHtml = '<h3>Przedmiot: ' + subjectName + '</h3>';
                studentsHtml += '<div class="student-list">';
                
                for (var i = 0; i < data.students.length; i++) {
                    var s = data.students[i];
                    studentsHtml += '<div class="student-item" data-student-id="' + s.id_uzytkownik + '">';
                    studentsHtml += '<h4>' + s.imie + ' ' + s.nazwisko + '</h4>';
                    studentsHtml += '<p>Klasa: ' + (s.klasa_nazwa || 'brak') + ' | Email: ' + s.email + '</p>';
                    studentsHtml += '<div class="grades-container" id="grades-container-' + s.id_uzytkownik + '"></div>';
                    studentsHtml += '</div>';
                }
                
                studentsHtml += '</div>';
                studentsContainer.innerHTML = studentsHtml;
                
                for (var i = 0; i < data.students.length; i++) {
                    var s = data.students[i];
                    loadGrades(s.id_uzytkownik, s.imie + ' ' + s.nazwisko);
                }
            })
            .catch(function(error) {
                console.error('Error loading students:', error);
                studentsContainer.innerHTML = '<div class="box"><p>Wystąpił błąd podczas ładowania uczniów.</p></div>';
            });
    }
    
    for (var i = 0; i < subjectLinks.length; i++) {
        var link = subjectLinks[i];
        link.addEventListener('click', function(e) {
            e.preventDefault();
            var subjectId = this.getAttribute('data-subject-id');
            var subjectName = this.getAttribute('data-subject-name');
            
            for (var j = 0; j < subjectLinks.length; j++) {
                subjectLinks[j].classList.remove('active');
            }
            this.classList.add('active');
            
            loadStudents(subjectId, subjectName);
        });
    }
    
    document.getElementById('gradeForm').onsubmit = function(e) {
        e.preventDefault();
        
        var gradeId = document.getElementById('gradeId').value;
        var formData = new FormData(this);
        
        var url = gradeId ? 'http://localhost/Dziennik_szkolny/amelia/public/index.php?action=teacherPanel&subaction=editGrade' 
                          : 'http://localhost/Dziennik_szkolny/amelia/public/index.php?action=teacherPanel&subaction=addGrade';
        
        fetch(url, {
            method: 'POST',
            body: formData
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.error) {
                alert(data.error);
            } else if (data.success) {
                alert(data.message);
                closeModal();
                var studentId = document.getElementById('gradeStudentId').value;
                var studentElement = document.querySelector('.student-item[data-student-id="' + studentId + '"]');
                if (studentElement) {
                    var studentName = studentElement.querySelector('h4').innerText;
                    loadGrades(studentId, studentName);
                }
            }
        })
        .catch(function(error) {
            alert('Wystąpił błąd: ' + error);
        });
    }
});
<?php echo '</script'; ?>
>

</body>
</html><?php }
}
