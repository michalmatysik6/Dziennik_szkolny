<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;

class StudentPanelCtrl {
    
    public function action_studentPanel() {
        
        $user_id = $_SESSION['user_id'] ?? null;
        
        if (!$user_id) {
            Utils::addErrorMessage("Brak identyfikatora użytkownika");
            header("Location: http://localhost/html5up-editorial/amelia/public/index.php?action=login");
            return;
        }
        
        try {
            $user_data = App::getDB()->get("uzytkownik", [
                "imie",
                "nazwisko",
                "email"
            ], [
                "id_uzytkownik" => $user_id
            ]);
            
            $user_email = $user_data['email'] ?? 'brak';
            $user_fullname = ucfirst(strtolower($user_data['imie'])) . ' ' . ucfirst(strtolower($user_data['nazwisko']));
            
            $user_role_display = "Uczeń";
            
            $classInfo = App::getDB()->get("uzytkownik", [
                "[>]klasa" => ["id_klasa" => "id_klasa"],
                "[>]uzytkownik (wychowawca)" => ["klasa.id_wychowawca" => "id_uzytkownik"]
            ], [
                "klasa.nazwa (klasa_nazwa)",
                "wychowawca.imie (wychowawca_imie)",
                "wychowawca.nazwisko (wychowawca_nazwisko)"
            ], [
                "uzytkownik.id_uzytkownik" => $user_id
            ]);
            
            $class_name = $classInfo['klasa_nazwa'] ?? 'Nieprzypisany do klasy';
            $homeroom_teacher = ($classInfo['wychowawca_imie'] && $classInfo['wychowawca_nazwisko']) 
                ? $classInfo['wychowawca_imie'] . ' ' . $classInfo['wychowawca_nazwisko']
                : 'Brak wychowawcy';
            
            $subjects = App::getDB()->query(
                "SELECT DISTINCT p.id_przedmiot, p.nazwa
                 FROM ocena o
                 JOIN przedmiot p ON o.id_przedmiot = p.id_przedmiot
                 WHERE o.id_uczen = :id_uczen
                 ORDER BY p.nazwa",
                [":id_uczen" => $user_id]
            )->fetchAll();
            
            App::getSmarty()->assign("user_id", $_SESSION['user_id']);
            App::getSmarty()->assign("user_name", $user_fullname);
            App::getSmarty()->assign("user_email", $user_email);
            App::getSmarty()->assign("user_role_display", $user_role_display);
            App::getSmarty()->assign("class_name", $class_name);
            App::getSmarty()->assign("homeroom_teacher", $homeroom_teacher);
            App::getSmarty()->assign("subjects", $subjects);
            
            App::getSmarty()->display("StudentPanel.tpl");
            
        } catch (\Exception $e) {
            Utils::addErrorMessage("Błąd: " . $e->getMessage());
            App::getSmarty()->display("StudentPanel.tpl");
        }
    }
    
    public function action_getGradesAjax() {
        header('Content-Type: application/json');
        
        $user_id = $_SESSION['user_id'] ?? null;
        if (!$user_id) {
            echo json_encode(['error' => 'Brak autoryzacji']);
            return;
        }
        
        $subject_id = ParamUtils::getFromGet('subject_id');
        if (!$subject_id) {
            echo json_encode(['error' => 'Nie wybrano przedmiotu']);
            return;
        }
        
        try {
            $check = App::getDB()->get("ocena", "id_ocena", [
                "id_uczen" => $user_id,
                "id_przedmiot" => $subject_id,
                "LIMIT" => 1
            ]);
            
            if (!$check) {
                echo json_encode(['error' => 'Brak ocen z tego przedmiotu']);
                return;
            }
            
            $subject_name = App::getDB()->get("przedmiot", "nazwa", [
                "id_przedmiot" => $subject_id
            ]);
            
            $grades = App::getDB()->query(
                "SELECT o.*, CONCAT(u.imie, ' ', u.nazwisko) as nauczyciel
                 FROM ocena o
                 JOIN uzytkownik u ON o.id_nauczyciel = u.id_uzytkownik
                 WHERE o.id_uczen = :id_uczen AND o.id_przedmiot = :id_przedmiot
                 ORDER BY o.data_wystawienia DESC",
                [
                    ":id_uczen" => $user_id,
                    ":id_przedmiot" => $subject_id
                ]
            )->fetchAll();
            
            $total_weighted = 0;
            $total_weight = 0;
            foreach ($grades as $grade) {
                $total_weighted += $grade['wartosc'] * $grade['waga'];
                $total_weight += $grade['waga'];
            }
            $weighted_average = $total_weight > 0 ? round($total_weighted / $total_weight, 2) : null;
            
            $total_values = 0;
            $count = 0;
            foreach ($grades as $grade) {
                $total_values += $grade['wartosc'];
                $count++;
            }
            $arithmetic_average = $count > 0 ? round($total_values / $count, 2) : null;
            
            echo json_encode([
                'success' => true,
                'subject_name' => $subject_name,
                'grades' => $grades,
                'weighted_average' => $weighted_average,
                'arithmetic_average' => $arithmetic_average
            ]);
            
        } catch (\Exception $e) {
            echo json_encode(['error' => 'Błąd bazy danych: ' . $e->getMessage()]);
        }
    }
    
}