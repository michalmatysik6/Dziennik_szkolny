<?php

namespace app\controllers;

use core\App;
use core\Utils;

class UserListCtrl {
    
    public function action_userList() {
        
        try {
            // Pobranie użytkowników wraz z rolami (GROUP_CONCAT zbiera role w jeden wiersz)
            $sql = "SELECT u.*, GROUP_CONCAT(r.nazwa SEPARATOR ', ') as role 
                    FROM uzytkownik u
                    LEFT JOIN uzytkownik_rola ur ON u.id_uzytkownik = ur.id_uzytkownik
                    LEFT JOIN rola r ON ur.id_rola = r.id_rola
                    GROUP BY u.id_uzytkownik
                    ORDER BY u.id_uzytkownik";
            
            $users = App::getDB()->query($sql)->fetchAll();
            
            // Przekazanie danych do widoku
            App::getSmarty()->assign("users", $users);
            App::getSmarty()->display("UserList.tpl");
            
        } catch (\Exception $e) {
            Utils::addErrorMessage("Błąd podczas pobierania użytkowników: " . $e->getMessage());
            App::getSmarty()->display("Hello.tpl");
        }
        
    }
    
}