<?php

namespace app\controllers;

use core\App;
use core\Utils;

class TestCtrl {
    
    public function action_test() {
        echo "Test działa!";
        exit;
    }
    
}