<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\RoleUtils;

class LoginController {
    
    public function action_login() {
        
        if (isset($_SESSION['user_id'])) {
            $this->redirectByRole();
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->processLogin();
        } else {
            $this->showLoginForm();
        }
    }
    
    private function processLogin() {
        
        $login = ParamUtils::getFromRequest('login');
        $pass = ParamUtils::getFromRequest('pass');
        
        $errors = false;
        if (empty($login)) {
            Utils::addErrorMessage("Login jest wymagany");
            $errors = true;
        }
        if (empty($pass)) {
            Utils::addErrorMessage("Hasło jest wymagane");
            $errors = true;
        }
        
        if ($errors) {
            $this->showLoginForm($login);
            return;
        }
        
        $user = App::getDB()->get("uzytkownik", "*", [
            "login" => $login,
            "aktywny" => 1
        ]);
        
        if (!$user) {
            Utils::addErrorMessage("Nieprawidłowy login lub hasło");
            $this->showLoginForm($login);
            return;
        }
        
        $hashed_password = hash('sha256', $pass);
        
        if ($hashed_password !== $user['haslo']) {
            Utils::addErrorMessage("Nieprawidłowy login lub hasło");
            $this->showLoginForm($login);
            return;
        }
        
        $roleIds = App::getDB()->select("uzytkownik_rola", "id_rola", [
            "id_uzytkownik" => $user['id_uzytkownik']
        ]);
        
        $userRoles = [];
        if ($roleIds) {
            foreach ($roleIds as $row) {
                $roleId = is_array($row) ? $row['id_rola'] : $row;
                $roleName = App::getDB()->get("rola", "nazwa", [
                    "id_rola" => $roleId,
                    "aktywna" => 1
                ]);
                if ($roleName) {
                    $userRoles[] = $roleName;
                    RoleUtils::addRole($roleName);
                }
            }
        }
        
        $_SESSION['user_id'] = $user['id_uzytkownik'];
        $_SESSION['user_name'] = $user['imie'] . ' ' . $user['nazwisko'];
        $_SESSION['user_roles'] = $userRoles;
        
        Utils::addInfoMessage("Zalogowano jako: " . $_SESSION['user_name']);
        
        $this->redirectByRole();
    }
    
    private function redirectByRole() {
        $roles = $_SESSION['user_roles'] ?? [];
        
        $url = "http://localhost/Dziennik_szkolny/amelia/public/index.php?action=";
        
        if (in_array('Admin', $roles)) {
            header("Location: " . $url . "adminPanel");
        } elseif (in_array('Nauczyciel', $roles)) {
            header("Location: " . $url . "teacherPanel");
        } elseif (in_array('Uczen', $roles)) {
            header("Location: " . $url . "studentPanel");
        } else {
            header("Location: " . $url . "login");
        }
        exit();
    }
    
    private function showLoginForm($login = '') {
        App::getSmarty()->assign("form", ['login' => $login]);
        App::getSmarty()->display("Login.tpl");
    }
    
    public function action_logout() {
        RoleUtils::removeRole("Admin");
        RoleUtils::removeRole("Nauczyciel");
        RoleUtils::removeRole("Uczen");
        unset($_SESSION['user_id']);
        unset($_SESSION['user_name']);
        unset($_SESSION['user_roles']);
        session_destroy();
        session_start();
        Utils::addInfoMessage("Zostałeś wylogowany");
        header("Location: http://localhost/Dziennik_szkolny/amelia/public/index.php?action=login");
        exit();
    }
    
}