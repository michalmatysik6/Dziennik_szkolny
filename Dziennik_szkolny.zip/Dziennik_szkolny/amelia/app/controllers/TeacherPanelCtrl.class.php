<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\RoleUtils;
use core\Validator;

class TeacherPanelCtrl {
    
    public function action_teacherPanel() {
        
        if (!RoleUtils::inRole('Nauczyciel')) {
            Utils::addErrorMessage("Brak dostępu");
            App::getRouter()->redirectTo("login");
            return;
        }
        
        $user_id = $_SESSION['user_id'] ?? null;
        
        if (!$user_id) {
            Utils::addErrorMessage("Brak identyfikatora użytkownika");
            App::getRouter()->redirectTo("login");
            return;
        }
        
        $action = ParamUtils::getFromGet('subaction');
        
        if ($action == 'getStudents') {
            $this->getStudentsAjax();
            return;
        }
        
        if ($action == 'addGrade') {
            $this->addGradeAjax();
            return;
        }
        
        if ($action == 'getGrades') {
            $this->getGradesAjax();
            return;
        }
        
        if ($action == 'editGrade') {
            $this->editGradeAjax();
            return;
        }
        
        if ($action == 'deleteGrade') {
            $this->deleteGradeAjax();
            return;
        }
        
        if ($action == 'getGrade') {
            $this->getGradeAjax();
            return;
        }
        
        $this->showMainPanel($user_id);
    }
    
    private function showMainPanel($user_id) {
        
        try {
            $subjects = App::getDB()->query(
                "SELECT p.id_przedmiot, p.nazwa, p.aktywny
                 FROM nauczyciel_przedmiot np
                 JOIN przedmiot p ON np.id_przedmiot = p.id_przedmiot
                 WHERE np.id_nauczyciel = :id_nauczyciel
                 ORDER BY p.nazwa",
                [":id_nauczyciel" => $user_id]
            )->fetchAll();
            
            $user_data = App::getDB()->get("uzytkownik", [
                "imie",
                "nazwisko",
                "email"
            ], [
                "id_uzytkownik" => $user_id
            ]);
            
            $user_fullname = ucfirst(strtolower($user_data['imie'])) . ' ' . ucfirst(strtolower($user_data['nazwisko']));
            
            App::getSmarty()->assign("user_id", $_SESSION['user_id']);
            App::getSmarty()->assign("user_name", $user_fullname);
            App::getSmarty()->assign("subjects", $subjects);
            
            App::getSmarty()->display("TeacherPanel.tpl");
            
        } catch (\Exception $e) {
            Utils::addErrorMessage("Błąd: " . $e->getMessage());
            App::getSmarty()->display("TeacherPanel.tpl");
        }
    }
    
    private function getStudentsAjax() {
        header('Content-Type: application/json');
        
        $teacher_id = $_SESSION['user_id'] ?? null;
        if (!$teacher_id) {
            echo json_encode(['error' => 'Brak autoryzacji']);
            return;
        }
        
        $subject_id = ParamUtils::getFromGet('subject_id');
        if (!$subject_id) {
            echo json_encode(['error' => 'Nie wybrano przedmiotu']);
            return;
        }
        
        try {
            $teacher_data = App::getDB()->get("uzytkownik", "id_klasa", [
                "id_uzytkownik" => $teacher_id
            ]);
            
            $teacher_class_id = $teacher_data['id_klasa'] ?? null;
            
            if (!$teacher_class_id) {
                $students = App::getDB()->query(
                    "SELECT DISTINCT u.id_uzytkownik, u.imie, u.nazwisko, u.email, k.nazwa as klasa_nazwa, u.id_klasa
                     FROM ocena o
                     JOIN uzytkownik u ON o.id_uczen = u.id_uzytkownik
                     LEFT JOIN klasa k ON u.id_klasa = k.id_klasa
                     WHERE o.id_przedmiot = :id_przedmiot AND o.id_nauczyciel = :id_nauczyciel
                     ORDER BY u.nazwisko, u.imie",
                    [
                        ":id_przedmiot" => $subject_id,
                        ":id_nauczyciel" => $teacher_id
                    ]
                )->fetchAll();
            } else {
                $students = App::getDB()->query(
                    "SELECT u.id_uzytkownik, u.imie, u.nazwisko, u.email, k.nazwa as klasa_nazwa, u.id_klasa
                     FROM uzytkownik u
                     LEFT JOIN klasa k ON u.id_klasa = k.id_klasa
                     WHERE u.id_klasa = :id_klasa AND u.aktywny = 1
                     ORDER BY u.nazwisko, u.imie",
                    [":id_klasa" => $teacher_class_id]
                )->fetchAll();
            }
            
            echo json_encode([
                'success' => true,
                'students' => $students
            ]);
            
        } catch (\Exception $e) {
            echo json_encode(['error' => 'Błąd bazy danych: ' . $e->getMessage()]);
        }
    }
    
    private function getGradesAjax() {
        header('Content-Type: application/json');
        
        $teacher_id = $_SESSION['user_id'] ?? null;
        if (!$teacher_id) {
            echo json_encode(['error' => 'Brak autoryzacji']);
            return;
        }
        
        $subject_id = ParamUtils::getFromGet('subject_id');
        $student_id = ParamUtils::getFromGet('student_id');
        $sort = ParamUtils::getFromGet('sort');
        
        if (!$subject_id || !$student_id) {
            echo json_encode(['error' => 'Brak wymaganych parametrów']);
            return;
        }
        
        $orderBy = "o.data_wystawienia DESC";
        if ($sort == 'date_asc') {
            $orderBy = "o.data_wystawienia ASC";
        } elseif ($sort == 'value_desc') {
            $orderBy = "o.wartosc DESC";
        } elseif ($sort == 'value_asc') {
            $orderBy = "o.wartosc ASC";
        } elseif ($sort == 'weight_desc') {
            $orderBy = "o.waga DESC";
        } elseif ($sort == 'weight_asc') {
            $orderBy = "o.waga ASC";
        }
        
        try {
            $grades = App::getDB()->query(
                "SELECT o.*, CONCAT(u.imie, ' ', u.nazwisko) as nauczyciel
                 FROM ocena o
                 JOIN uzytkownik u ON o.id_nauczyciel = u.id_uzytkownik
                 WHERE o.id_uczen = :id_uczen AND o.id_przedmiot = :id_przedmiot
                 ORDER BY " . $orderBy,
                [
                    ":id_uczen" => $student_id,
                    ":id_przedmiot" => $subject_id
                ]
            )->fetchAll();
            
            echo json_encode([
                'success' => true,
                'grades' => $grades
            ]);
            
        } catch (\Exception $e) {
            echo json_encode(['error' => 'Błąd bazy danych: ' . $e->getMessage()]);
        }
    }
    
    private function getGradeAjax() {
        header('Content-Type: application/json');
        
        $teacher_id = $_SESSION['user_id'] ?? null;
        if (!$teacher_id) {
            echo json_encode(['error' => 'Brak autoryzacji']);
            return;
        }
        
        $grade_id = ParamUtils::getFromGet('grade_id');
        if (!$grade_id) {
            echo json_encode(['error' => 'Brak ID oceny']);
            return;
        }
        
        try {
            $grade = App::getDB()->get("ocena", "*", [
                "id_ocena" => $grade_id
            ]);
            
            if (!$grade) {
                echo json_encode(['error' => 'Ocena nie istnieje']);
                return;
            }
            
            $check = App::getDB()->get("ocena", "id_ocena", [
                "id_ocena" => $grade_id,
                "id_nauczyciel" => $teacher_id
            ]);
            
            if (!$check) {
                echo json_encode(['error' => 'Nie masz uprawnień do edycji tej oceny']);
                return;
            }
            
            echo json_encode([
                'success' => true,
                'grade' => $grade
            ]);
            
        } catch (\Exception $e) {
            echo json_encode(['error' => 'Błąd bazy danych: ' . $e->getMessage()]);
        }
    }
    
    private function editGradeAjax() {
        header('Content-Type: application/json');
        
        $teacher_id = $_SESSION['user_id'] ?? null;
        if (!$teacher_id) {
            echo json_encode(['error' => 'Brak autoryzacji']);
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['error' => 'Nieprawidłowe żądanie']);
            return;
        }
        
        $grade_id = ParamUtils::getFromPost('grade_id');
        $wartosc = ParamUtils::getFromPost('wartosc');
        $waga = ParamUtils::getFromPost('waga');
        $opis = ParamUtils::getFromPost('opis');
        $data_wystawienia = ParamUtils::getFromPost('data_wystawienia');
        
        $errors = [];
        
        if (empty($grade_id)) {
            $errors[] = 'Brak ID oceny';
        }
        
        if (empty($wartosc)) {
            $errors[] = 'Ocena jest wymagana';
        } elseif (!is_numeric($wartosc) || $wartosc < 1 || $wartosc > 6) {
            $errors[] = 'Ocena musi być liczbą od 1 do 6';
        }
        
        if (empty($waga)) {
            $errors[] = 'Waga jest wymagana';
        } elseif (!is_numeric($waga) || $waga < 1 || $waga > 10) {
            $errors[] = 'Waga musi być liczbą od 1 do 10';
        }
        
        if (empty($data_wystawienia)) {
            $errors[] = 'Data wystawienia jest wymagana';
        } else {
            $today = date('Y-m-d');
            if ($data_wystawienia > $today) {
                $errors[] = 'Data nie może być z przyszłości';
            }
        }
        
        if (!empty($errors)) {
            echo json_encode(['error' => implode('; ', $errors)]);
            return;
        }
        
        try {
            $old_grade = App::getDB()->get("ocena", "*", [
                "id_ocena" => $grade_id,
                "id_nauczyciel" => $teacher_id
            ]);
            
            if (!$old_grade) {
                echo json_encode(['error' => 'Nie masz uprawnień do edycji tej oceny']);
                return;
            }
            
            App::getDB()->update("ocena", [
                "wartosc" => $wartosc,
                "waga" => $waga,
                "opis" => $opis,
                "data_wystawienia" => $data_wystawienia
            ], [
                "id_ocena" => $grade_id
            ]);
            
            $changes = [];
            if ($old_grade['wartosc'] != $wartosc) {
                $changes[] = "wartosc: {$old_grade['wartosc']} -> {$wartosc}";
            }
            if ($old_grade['waga'] != $waga) {
                $changes[] = "waga: {$old_grade['waga']} -> {$waga}";
            }
            if ($old_grade['opis'] != $opis) {
                $changes[] = "zmiana opisu";
            }
            if ($old_grade['data_wystawienia'] != $data_wystawienia) {
                $changes[] = "data: {$old_grade['data_wystawienia']} -> {$data_wystawienia}";
            }
            
            App::getDB()->insert("historia_oceny", [
                "id_ocena" => $grade_id,
                "wartosc_stara" => $old_grade['wartosc'],
                "wartosc_nowa" => $wartosc,
                "waga_stara" => $old_grade['waga'],
                "waga_nowa" => $waga,
                "opis_stary" => $old_grade['opis'],
                "opis_nowy" => $opis,
                "data_zmiany" => date('Y-m-d H:i:s'),
                "id_uzytkownik" => $teacher_id,
                "rodzaj_operacji" => "EDYCJA"
            ]);
            
            echo json_encode(['success' => true, 'message' => 'Ocena została zaktualizowana. Zmiany: ' . implode(', ', $changes)]);
            
        } catch (\Exception $e) {
            echo json_encode(['error' => 'Błąd bazy danych: ' . $e->getMessage()]);
        }
    }
    
    private function deleteGradeAjax() {
        header('Content-Type: application/json');
        
        $teacher_id = $_SESSION['user_id'] ?? null;
        if (!$teacher_id) {
            echo json_encode(['error' => 'Brak autoryzacji']);
            return;
        }
        
        $grade_id = ParamUtils::getFromPost('grade_id');
        
        if (!$grade_id) {
            echo json_encode(['error' => 'Brak ID oceny']);
            return;
        }
        
        try {
            $old_grade = App::getDB()->get("ocena", "*", [
                "id_ocena" => $grade_id,
                "id_nauczyciel" => $teacher_id
            ]);
            
            if (!$old_grade) {
                echo json_encode(['error' => 'Nie masz uprawnień do usunięcia tej oceny']);
                return;
            }
            
            App::getDB()->insert("historia_oceny", [
                "id_ocena" => $grade_id,
                "wartosc_stara" => $old_grade['wartosc'],
                "wartosc_nowa" => 0,
                "waga_stara" => $old_grade['waga'],
                "waga_nowa" => 0,
                "opis_stary" => $old_grade['opis'],
                "opis_nowy" => null,
                "data_zmiany" => date('Y-m-d H:i:s'),
                "id_uzytkownik" => $teacher_id,
                "rodzaj_operacji" => "USUNIECIE"
            ]);
            
            App::getDB()->delete("ocena", [
                "id_ocena" => $grade_id
            ]);
            
            echo json_encode(['success' => true, 'message' => 'Ocena została usunięta']);
            
        } catch (\Exception $e) {
            echo json_encode(['error' => 'Błąd bazy danych: ' . $e->getMessage()]);
        }
    }
    
    private function addGradeAjax() {
        header('Content-Type: application/json');
        
        $teacher_id = $_SESSION['user_id'] ?? null;
        if (!$teacher_id) {
            echo json_encode(['error' => 'Brak autoryzacji']);
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['error' => 'Nieprawidłowe żądanie']);
            return;
        }
        
        $subject_id = ParamUtils::getFromPost('subject_id');
        $student_id = ParamUtils::getFromPost('student_id');
        $wartosc = ParamUtils::getFromPost('wartosc');
        $waga = ParamUtils::getFromPost('waga');
        $opis = ParamUtils::getFromPost('opis');
        $data_wystawienia = ParamUtils::getFromPost('data_wystawienia');
        
        $errors = [];
        
        if (empty($subject_id)) {
            $errors[] = 'Przedmiot jest wymagany';
        }
        
        if (empty($student_id)) {
            $errors[] = 'Uczeń jest wymagany';
        }
        
        if (empty($wartosc)) {
            $errors[] = 'Ocena jest wymagana';
        } elseif (!is_numeric($wartosc) || $wartosc < 1 || $wartosc > 6) {
            $errors[] = 'Ocena musi być liczbą od 1 do 6';
        }
        
        if (empty($waga)) {
            $errors[] = 'Waga jest wymagana';
        } elseif (!is_numeric($waga) || $waga < 1 || $waga > 10) {
            $errors[] = 'Waga musi być liczbą od 1 do 10';
        }
        
        if (empty($data_wystawienia)) {
            $errors[] = 'Data wystawienia jest wymagana';
        } else {
            $today = date('Y-m-d');
            if ($data_wystawienia > $today) {
                $errors[] = 'Data nie może być z przyszłości';
            }
        }
        
        if (!empty($errors)) {
            echo json_encode(['error' => implode('; ', $errors)]);
            return;
        }
        
        try {
            App::getDB()->insert("ocena", [
                "wartosc" => $wartosc,
                "waga" => $waga,
                "opis" => $opis,
                "data_wystawienia" => $data_wystawienia,
                "id_uczen" => $student_id,
                "id_nauczyciel" => $teacher_id,
                "id_przedmiot" => $subject_id
            ]);
            
            $new_grade_id = App::getDB()->id();
            
            App::getDB()->insert("historia_oceny", [
                "id_ocena" => $new_grade_id,
                "wartosc_nowa" => $wartosc,
                "waga_nowa" => $waga,
                "opis_nowy" => $opis,
                "data_zmiany" => date('Y-m-d H:i:s'),
                "id_uzytkownik" => $teacher_id,
                "rodzaj_operacji" => "UTWORZENIE"
            ]);
            
            echo json_encode(['success' => true, 'message' => 'Ocena została dodana']);
            
        } catch (\Exception $e) {
            echo json_encode(['error' => 'Błąd bazy danych: ' . $e->getMessage()]);
        }
    }
    
}