<?php

namespace app\controllers;

use core\App;
use core\Utils;
use core\ParamUtils;
use core\RoleUtils;
use core\Validator;

class AdminPanelCtrl {
    
    public function action_adminPanel() {
        
        if (!RoleUtils::inRole('Admin')) {
            Utils::addErrorMessage("Brak dostępu");
            App::getRouter()->redirectTo("login");
            return;
        }
        
        $this->showUserList();
    }
    
    private function showUserList() {
        
        $page = ParamUtils::getFromGet('page', true);
        $page = isset($page) && is_numeric($page) ? (int)$page : 1;
        $perPage = 10;
        $offset = ($page - 1) * $perPage;
        
        $search_login = ParamUtils::getFromGet('search_login');
        $search_imie = ParamUtils::getFromGet('search_imie');
        $search_nazwisko = ParamUtils::getFromGet('search_nazwisko');
        $search_rola = ParamUtils::getFromGet('search_rola');
        
        $where = [];
        $params = [];
        
        if (!empty($search_login)) {
            $where[] = "u.login LIKE :login";
            $params[':login'] = "%{$search_login}%";
        }
        if (!empty($search_imie)) {
            $where[] = "u.imie LIKE :imie";
            $params[':imie'] = "%{$search_imie}%";
        }
        if (!empty($search_nazwisko)) {
            $where[] = "u.nazwisko LIKE :nazwisko";
            $params[':nazwisko'] = "%{$search_nazwisko}%";
        }
        if (!empty($search_rola) && $search_rola !== 'wszystkie') {
            $where[] = "r.nazwa = :rola";
            $params[':rola'] = $search_rola;
        }
        
        $whereClause = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";
        
        $sqlCount = "SELECT COUNT(DISTINCT u.id_uzytkownik) as total 
                     FROM uzytkownik u
                     LEFT JOIN uzytkownik_rola ur ON u.id_uzytkownik = ur.id_uzytkownik
                     LEFT JOIN rola r ON ur.id_rola = r.id_rola
                     {$whereClause}";
        
        $totalResult = App::getDB()->query($sqlCount, $params)->fetch();
        $totalUsers = $totalResult['total'];
        $totalPages = ceil($totalUsers / $perPage);
        
        $sql = "SELECT u.*, GROUP_CONCAT(r.nazwa SEPARATOR ', ') as role, 
                       k.nazwa as klasa_nazwa
                FROM uzytkownik u
                LEFT JOIN uzytkownik_rola ur ON u.id_uzytkownik = ur.id_uzytkownik
                LEFT JOIN rola r ON ur.id_rola = r.id_rola
                LEFT JOIN klasa k ON u.id_klasa = k.id_klasa
                {$whereClause}
                GROUP BY u.id_uzytkownik
                ORDER BY u.id_uzytkownik
                LIMIT {$offset}, {$perPage}";
        
        $users = App::getDB()->query($sql, $params)->fetchAll();
        
        $roles = App::getDB()->select("rola", "*", ["aktywna" => 1]);
        $classes = App::getDB()->select("klasa", "*", ["aktywna" => 1]);
        
        App::getSmarty()->assign("users", $users);
        App::getSmarty()->assign("roles", $roles);
        App::getSmarty()->assign("classes", $classes);
        App::getSmarty()->assign("page", $page);
        App::getSmarty()->assign("totalPages", $totalPages);
        App::getSmarty()->assign("search_login", $search_login);
        App::getSmarty()->assign("search_imie", $search_imie);
        App::getSmarty()->assign("search_nazwisko", $search_nazwisko);
        App::getSmarty()->assign("search_rola", $search_rola);
        App::getSmarty()->assign("user_id", $_SESSION['user_id']);
        App::getSmarty()->assign("user_name", $_SESSION['user_name']);
        
        App::getSmarty()->display("AdminPanel.tpl");
    }
    
    public function action_adminAddUser() {
        
        if (!RoleUtils::inRole('Admin')) {
            echo json_encode(['error' => 'Brak dostępu']);
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['error' => 'Nieprawidłowe żądanie']);
            return;
        }
        
        $validator = new Validator();
        $errors = [];
        
        $login = $validator->validateFromPost('login', [
            'required' => true,
            'required_message' => 'Login jest wymagany',
            'min_length' => 3,
            'max_length' => 45
        ]);
        
        if (!$validator->isLastOK()) {
            $errors[] = 'Login jest wymagany (min. 3 znaki)';
        }
        
        $haslo = $validator->validateFromPost('haslo', [
            'required' => true,
            'required_message' => 'Hasło jest wymagane',
            'min_length' => 4
        ]);
        
        if (!$validator->isLastOK()) {
            $errors[] = 'Hasło jest wymagane (min. 4 znaki)';
        }
        
        $imie = $validator->validateFromPost('imie', [
            'required' => true,
            'required_message' => 'Imię jest wymagane',
            'max_length' => 45
        ]);
        
        if (!$validator->isLastOK()) {
            $errors[] = 'Imię jest wymagane';
        }
        
        $nazwisko = $validator->validateFromPost('nazwisko', [
            'required' => true,
            'required_message' => 'Nazwisko jest wymagane',
            'max_length' => 45
        ]);
        
        if (!$validator->isLastOK()) {
            $errors[] = 'Nazwisko jest wymagane';
        }
        
        $email = $validator->validateFromPost('email', [
            'required' => true,
            'required_message' => 'Email jest wymagany',
            'email' => true
        ]);
        
        if (!$validator->isLastOK()) {
            $errors[] = 'Podaj poprawny adres email';
        }
        
        $id_klasa = ParamUtils::getFromPost('id_klasa');
        $role_ids = ParamUtils::getFromPost('role_ids');
        if (!is_array($role_ids)) {
            $role_ids = [];
        }
        
        if (count($role_ids) == 0) {
            $errors[] = 'Wybierz co najmniej jedną rolę dla użytkownika';
        }
        
        if (!empty($errors)) {
            echo json_encode(['error' => implode('; ', $errors)]);
            return;
        }
        
        $existingLogin = App::getDB()->get("uzytkownik", "id_uzytkownik", [
            "login" => $login
        ]);
        
        if ($existingLogin) {
            echo json_encode(['error' => 'Użytkownik o tym loginie już istnieje']);
            return;
        }
        
        $existingEmail = App::getDB()->get("uzytkownik", "id_uzytkownik", [
            "email" => $email
        ]);
        
        if ($existingEmail) {
            echo json_encode(['error' => 'Użytkownik o tym adresie email już istnieje']);
            return;
        }
        
        $hashed_password = hash('sha256', $haslo);
        
        App::getDB()->insert("uzytkownik", [
            "login" => $login,
            "haslo" => $hashed_password,
            "imie" => ucfirst(strtolower($imie)),
            "nazwisko" => ucfirst(strtolower($nazwisko)),
            "email" => $email,
            "aktywny" => 1,
            "id_klasa" => !empty($id_klasa) ? $id_klasa : null,
            "kto_utworzyl" => $_SESSION['user_id'],
            "kiedy_utworzyl" => date('Y-m-d H:i:s')
        ]);
        
        $newUserId = App::getDB()->id();
        
        foreach ($role_ids as $role_id) {
            App::getDB()->insert("uzytkownik_rola", [
                "id_uzytkownik" => $newUserId,
                "id_rola" => $role_id,
                "data_nadania" => date('Y-m-d H:i:s'),
                "kto_nadal" => $_SESSION['user_id']
            ]);
        }
        
        echo json_encode(['success' => true, 'message' => 'Użytkownik został dodany']);
    }
    
    public function action_adminDeleteUser() {
        
        if (!RoleUtils::inRole('Admin')) {
            echo json_encode(['error' => 'Brak dostępu']);
            return;
        }
        
        $id_uzytkownik = ParamUtils::getFromPost('id_uzytkownik');
        
        if (!$id_uzytkownik) {
            echo json_encode(['error' => 'Brak ID użytkownika']);
            return;
        }
        
        if ($id_uzytkownik == $_SESSION['user_id']) {
            echo json_encode(['error' => 'Nie możesz usunąć samego siebie']);
            return;
        }
        
        App::getDB()->delete("uzytkownik_rola", ["id_uzytkownik" => $id_uzytkownik]);
        App::getDB()->delete("uzytkownik", ["id_uzytkownik" => $id_uzytkownik]);
        
        echo json_encode(['success' => true, 'message' => 'Użytkownik został usunięty']);
    }
    
    public function action_adminEditUser() {
        
        if (!RoleUtils::inRole('Admin')) {
            echo json_encode(['error' => 'Brak dostępu']);
            return;
        }
        
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['error' => 'Nieprawidłowe żądanie']);
            return;
        }
        
        $id_uzytkownik = ParamUtils::getFromPost('id_uzytkownik');
        
        $validator = new Validator();
        $errors = [];
        
        $imie = $validator->validateFromPost('imie', [
            'required' => true,
            'required_message' => 'Imię jest wymagane',
            'max_length' => 45
        ]);
        
        if (!$validator->isLastOK()) {
            $errors[] = 'Imię jest wymagane';
        }
        
        $nazwisko = $validator->validateFromPost('nazwisko', [
            'required' => true,
            'required_message' => 'Nazwisko jest wymagane',
            'max_length' => 45
        ]);
        
        if (!$validator->isLastOK()) {
            $errors[] = 'Nazwisko jest wymagane';
        }
        
        $email = $validator->validateFromPost('email', [
            'required' => true,
            'required_message' => 'Email jest wymagany',
            'email' => true
        ]);
        
        if (!$validator->isLastOK()) {
            $errors[] = 'Podaj poprawny adres email';
        }
        
        $aktywny = ParamUtils::getFromPost('aktywny') ? 1 : 0;
        $id_klasa = ParamUtils::getFromPost('id_klasa');
        $haslo = ParamUtils::getFromPost('haslo');
        $role_ids = ParamUtils::getFromPost('role_ids');
        
        if (!is_array($role_ids)) {
            $role_ids = [];
        }
        
        if (count($role_ids) == 0) {
            $errors[] = 'Wybierz co najmniej jedną rolę dla użytkownika';
        }
        
        if (!empty($errors)) {
            echo json_encode(['error' => implode('; ', $errors)]);
            return;
        }
        
        if ($id_uzytkownik == $_SESSION['user_id']) {
            $userRoles = App::getDB()->select("uzytkownik_rola", "id_rola", [
                "id_uzytkownik" => $id_uzytkownik
            ]);
            
            $currentRoleIds = [];
            foreach ($userRoles as $row) {
                $currentRoleIds[] = is_array($row) ? $row['id_rola'] : $row;
            }
            
            $adminRole = App::getDB()->get("rola", "id_rola", ["nazwa" => "Admin"]);
            $hadAdminBefore = in_array($adminRole['id_rola'], $currentRoleIds);
            $hasAdminNow = in_array($adminRole['id_rola'], $role_ids);
            
            if ($hadAdminBefore && !$hasAdminNow) {
                echo json_encode(['error' => 'Nie możesz odebrać sobie roli Administratora']);
                return;
            }
        }
        
        $updateData = [
            "imie" => ucfirst(strtolower($imie)),
            "nazwisko" => ucfirst(strtolower($nazwisko)),
            "email" => $email,
            "aktywny" => $aktywny,
            "id_klasa" => !empty($id_klasa) ? $id_klasa : null,
            "kto_zmodyfikowal" => $_SESSION['user_id'],
            "kiedy_zmodyfikowal" => date('Y-m-d H:i:s')
        ];
        
        if (!empty($haslo)) {
            if (strlen($haslo) < 4) {
                echo json_encode(['error' => 'Hasło musi mieć co najmniej 4 znaki']);
                return;
            }
            $updateData['haslo'] = hash('sha256', $haslo);
        }
        
        App::getDB()->update("uzytkownik", $updateData, [
            "id_uzytkownik" => $id_uzytkownik
        ]);
        
        App::getDB()->delete("uzytkownik_rola", ["id_uzytkownik" => $id_uzytkownik]);
        
        foreach ($role_ids as $role_id) {
            App::getDB()->insert("uzytkownik_rola", [
                "id_uzytkownik" => $id_uzytkownik,
                "id_rola" => $role_id,
                "data_nadania" => date('Y-m-d H:i:s'),
                "kto_nadal" => $_SESSION['user_id']
            ]);
        }
        
        echo json_encode(['success' => true, 'message' => 'Użytkownik został zaktualizowany']);
    }
    
    public function action_adminGetUser() {
        
        if (!RoleUtils::inRole('Admin')) {
            echo json_encode(['error' => 'Brak dostępu']);
            return;
        }
        
        $id_uzytkownik = ParamUtils::getFromGet('id');
        
        if (!$id_uzytkownik) {
            echo json_encode(['error' => 'Brak ID użytkownika']);
            return;
        }
        
        $user = App::getDB()->get("uzytkownik", "*", [
            "id_uzytkownik" => $id_uzytkownik
        ]);
        
        if (!$user) {
            echo json_encode(['error' => 'Użytkownik nie istnieje']);
            return;
        }
        
        $userRoles = App::getDB()->select("uzytkownik_rola", "id_rola", [
            "id_uzytkownik" => $id_uzytkownik
        ]);
        
        $roleIds = [];
        foreach ($userRoles as $row) {
            $roleIds[] = is_array($row) ? $row['id_rola'] : $row;
        }
        
        echo json_encode([
            'success' => true,
            'user' => $user,
            'roles' => $roleIds
        ]);
    }
    
    private function getErrorMessages() {
        $messages = [];
        foreach (App::getMessages()->getMessages() as $msg) {
            if ($msg->isError()) {
                $messages[] = $msg->text;
            }
        }
        return $messages;
    }
    
}