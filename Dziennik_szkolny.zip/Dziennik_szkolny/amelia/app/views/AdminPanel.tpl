<!DOCTYPE HTML>
<html>
<head>
    <title>Panel Admina - Dziennik szkolny</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="http://localhost/Dziennik_szkolny/assets/css/main.css" />
    <style>
        .modal {
            display: none;
            position: fixed;
            z-index: 20000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: #fff;
            margin: 5% auto;
            padding: 20px;
            width: 50%;
            max-width: 600px;
            border-radius: 8px;
            position: relative;
            z-index: 20001;
        }
        .close {
            position: absolute;
            right: 20px;
            top: 10px;
            font-size: 28px;
            cursor: pointer;
        }
        .pagination {
            margin-top: 20px;
            text-align: center;
        }
        .pagination a {
            display: inline-block;
            padding: 8px 12px;
            margin: 0 4px;
            border: 1px solid #ddd;
            text-decoration: none;
            color: #333;
        }
        .pagination a.active {
            background-color: #f56a6a;
            color: white;
            border-color: #f56a6a;
        }
        .filter-form {
            margin-bottom: 20px;
            padding: 15px;
            background: #f5f6f7;
            border-radius: 8px;
        }
        .filter-form input, .filter-form select {
            margin-right: 10px;
            padding: 8px;
        }
        .btn-small {
            padding: 4px 8px;
            font-size: 12px;
            margin: 2px;
        }
        .roles-container {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 10px;
            margin-bottom: 15px;
        }
        .roles-container label {
            cursor: pointer;
            background: #f0f0f0;
            padding: 8px 15px;
            border-radius: 4px;
            margin: 0;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .roles-container input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
            margin: 0;
            opacity: 1;
            position: relative;
            left: auto;
            top: auto;
            float: none;
        }
        .roles-container label.checked {
            background: #f56a6a;
            color: white;
        }
    </style>
</head>
<body class="is-preload">

<div id="wrapper">
    <div id="sidebar">
        <div class="inner">
            <nav id="menu">
                <header class="major">
                    <h2>Menu Admina</h2>
                </header>
                <ul>
                    <li><a href="http://localhost/Dziennik_szkolny/amelia/public/index.php?action=adminPanel">Zarządzanie użytkownikami</a></li>
                </ul>
            </nav>
            
            <section>
                <header class="major">
                    <h2>Informacje</h2>
                </header>
                <div class="mini-posts">
                    <article>
                        <p><strong>Zalogowany:</strong> {$user_name}</p>
                        <p><strong>Rola:</strong> Administrator</p>
                    </article>
                </div>
            </section>
            
            <footer id="footer">
                <a href="http://localhost/Dziennik_szkolny/amelia/public/index.php?action=logout" class="button primary fit">Wyloguj się</a>
            </footer>
        </div>
    </div>

    <div id="main">
        <div class="inner">
            <header id="header">
                <a href="#" class="logo"><strong>Dziennik szkolny</strong> - Panel Admina</a>
            </header>
            
            <section>
                <header class="main">
                    <h1>Zarządzanie użytkownikami</h1>
                </header>
                
                <div style="margin-bottom: 20px;">
                    <button id="addUserBtn" class="button primary">+ Dodaj nowego użytkownika</button>
                </div>
                
                <div class="filter-form">
                    <h3>Filtrowanie</h3>
                    <form method="get" action="http://localhost/Dziennik_szkolny/amelia/public/index.php">
                        <input type="hidden" name="action" value="adminPanel">
                        <input type="text" name="search_login" placeholder="Login" value="{$search_login}">
                        <input type="text" name="search_imie" placeholder="Imię" value="{$search_imie}">
                        <input type="text" name="search_nazwisko" placeholder="Nazwisko" value="{$search_nazwisko}">
                        <select name="search_rola">
                            <option value="wszystkie" {if $search_rola == 'wszystkie' || !$search_rola}selected{/if}>Wszystkie role</option>
                            {foreach $roles as $r}
                            <option value="{$r.nazwa}" {if $search_rola == $r.nazwa}selected{/if}>{$r.nazwa}</option>
                            {/foreach}
                        </select>
                        <button type="submit" class="button">Filtruj</button>
                        <a href="http://localhost/Dziennik_szkolny/amelia/public/index.php?action=adminPanel" class="button">Wyczyść</a>
                    </form>
                </div>
                
                <div class="table-wrapper">
                    <table class="alt">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Login</th>
                                <th>Imię</th>
                                <th>Nazwisko</th>
                                <th>Email</th>
                                <th>Klasa</th>
                                <th>Role</th>
                                <th>Aktywny</th>
                                <th>Akcje</th>
                            </tr>
                        </thead>
                        <tbody>
                            {foreach $users as $u}
                            <tr>
                                <td>{$u.id_uzytkownik}</td>
                                <td>{$u.login}</td>
                                <td>{$u.imie}</td>
                                <td>{$u.nazwisko}</td>
                                <td>{$u.email}</td>
                                <td>{$u.klasa_nazwa|default:'-'}</td>
                                <td>{$u.role|default:'brak'}</td>
                                <td>{if $u.aktywny}Tak{else}Nie{/if}</td>
                                <td>
                                    <button class="button small editUserBtn" data-id="{$u.id_uzytkownik}">Edytuj</button>
                                    <button class="button small deleteUserBtn" data-id="{$u.id_uzytkownik}" data-name="{$u.imie} {$u.nazwisko}">Usuń</button>
                                </td>
                            </tr>
                            {foreachelse}
                            <tr>
                                <td colspan="9">Brak użytkowników</td>
                            </tr>
                            {/foreach}
                        </tbody>
                    </table>
                </div>
                
                {if $totalPages > 1}
                <div class="pagination">
                    {for $p=1 to $totalPages}
                        <a href="http://localhost/Dziennik_szkolny/amelia/public/index.php?action=adminPanel&page={$p}&search_login={$search_login}&search_imie={$search_imie}&search_nazwisko={$search_nazwisko}&search_rola={$search_rola}" class="{if $p == $page}active{/if}">{$p}</a>
                    {/for}
                </div>
                {/if}
                
            </section>
        </div>
    </div>
</div>

<div id="userModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3 id="modalTitle">Dodaj użytkownika</h3>
        <form id="userForm">
            <input type="hidden" name="id_uzytkownik" id="editId">
            
            <div class="row gtr-uniform">
                <div class="col-6">
                    <label>Login *</label>
                    <input type="text" name="login" id="login" required>
                </div>
                <div class="col-6">
                    <label>Hasło <span id="passwordLabel">*</span></label>
                    <input type="password" name="haslo" id="haslo">
                </div>
                <div class="col-6">
                    <label>Imię *</label>
                    <input type="text" name="imie" id="imie" required>
                </div>
                <div class="col-6">
                    <label>Nazwisko *</label>
                    <input type="text" name="nazwisko" id="nazwisko" required>
                </div>
                <div class="col-6">
                    <label>Email *</label>
                    <input type="email" name="email" id="email" required>
                </div>
                <div class="col-6">
                    <label>Klasa</label>
                    <select name="id_klasa" id="id_klasa">
                        <option value="">Brak</option>
                        {foreach $classes as $c}
                        <option value="{$c.id_klasa}">{$c.nazwa}</option>
                        {/foreach}
                    </select>
                </div>
                <div class="col-12">
                    <label>Role</label>
                    <div class="roles-container" id="rolesCheckboxes">
                        {foreach $roles as $r}
                        <label class="role-label">
                            <input type="checkbox" name="role_ids[]" value="{$r.id_rola}"> {$r.nazwa}
                        </label>
                        {/foreach}
                    </div>
                </div>
                <div class="col-12" id="aktywnyField" style="display:none;">
                    <label>
                        <input type="checkbox" name="aktywny" id="aktywny" value="1"> Aktywny
                    </label>
                </div>
                <div class="col-12">
                    <ul class="actions">
                        <li><input type="submit" value="Zapisz" class="primary"></li>
                        <li><button type="button" class="closeBtn">Anuluj</button></li>
                    </ul>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="http://localhost/Dziennik_szkolny/assets/js/jquery.min.js"></script>
<script src="http://localhost/Dziennik_szkolny/assets/js/browser.min.js"></script>
<script src="http://localhost/Dziennik_szkolny/assets/js/breakpoints.min.js"></script>
<script src="http://localhost/Dziennik_szkolny/assets/js/util.js"></script>
<script src="http://localhost/Dziennik_szkolny/assets/js/main.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var modal = document.getElementById('userModal');
    var span = document.getElementsByClassName('close')[0];
    var closeBtns = document.getElementsByClassName('closeBtn');

    function openModal() {
        modal.style.display = 'block';
    }

    function closeModal() {
        modal.style.display = 'none';
        document.getElementById('userForm').reset();
        document.getElementById('editId').value = '';
        document.getElementById('modalTitle').innerHTML = 'Dodaj użytkownika';
        document.getElementById('passwordLabel').innerHTML = '*';
        document.getElementById('haslo').required = true;
        document.getElementById('haslo').placeholder = '';
        document.getElementById('aktywnyField').style.display = 'none';
        document.getElementById('login').disabled = false;
        
        var checkboxes = document.querySelectorAll('input[name="role_ids[]"]');
        for (var j = 0; j < checkboxes.length; j++) {
            checkboxes[j].checked = false;
            checkboxes[j].parentNode.classList.remove('checked');
        }
    }

    if (span) span.onclick = closeModal;
    for (var i = 0; i < closeBtns.length; i++) {
        closeBtns[i].onclick = closeModal;
    }
    window.onclick = function(event) {
        if (event.target == modal) {
            closeModal();
        }
    }

    document.getElementById('addUserBtn').onclick = function() {
        openModal();
    }

    document.getElementById('userForm').onsubmit = function(e) {
        e.preventDefault();
        
        var formData = new FormData(this);
        var id = document.getElementById('editId').value;
        var url = 'http://localhost/Dziennik_szkolny/amelia/public/index.php?action=' + (id ? 'adminEditUser' : 'adminAddUser');
        
        fetch(url, {
            method: 'POST',
            body: formData
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.error) {
                alert(data.error);
            } else if (data.success) {
                alert(data.message);
                location.reload();
            }
        })
        .catch(function(error) {
            alert('Wystąpił błąd: ' + error);
        });
    }

    var editBtns = document.querySelectorAll('.editUserBtn');
    for (var i = 0; i < editBtns.length; i++) {
        editBtns[i].onclick = function() {
            var id = this.getAttribute('data-id');
            
            fetch('http://localhost/Dziennik_szkolny/amelia/public/index.php?action=adminGetUser&id=' + id)
                .then(function(response) {
                    return response.json();
                })
                .then(function(data) {
                    if (data.error) {
                        alert(data.error);
                        return;
                    }
                    
                    document.getElementById('editId').value = data.user.id_uzytkownik;
                    document.getElementById('login').value = data.user.login;
                    document.getElementById('login').disabled = true;
                    document.getElementById('imie').value = data.user.imie;
                    document.getElementById('nazwisko').value = data.user.nazwisko;
                    document.getElementById('email').value = data.user.email;
                    document.getElementById('id_klasa').value = data.user.id_klasa || '';
                    document.getElementById('haslo').required = false;
                    document.getElementById('haslo').placeholder = '( pozostaw puste aby nie zmieniać )';
                    document.getElementById('passwordLabel').innerHTML = '(opcjonalne)';
                    document.getElementById('aktywnyField').style.display = 'block';
                    document.getElementById('aktywny').checked = data.user.aktywny == 1;
                    
                    var checkboxes = document.querySelectorAll('input[name="role_ids[]"]');
                    for (var j = 0; j < checkboxes.length; j++) {
                        checkboxes[j].checked = false;
                        checkboxes[j].parentNode.classList.remove('checked');
                    }
                    for (var j = 0; j < data.roles.length; j++) {
                        var cb = document.querySelector('input[name="role_ids[]"][value="' + data.roles[j] + '"]');
                        if (cb) {
                            cb.checked = true;
                            cb.parentNode.classList.add('checked');
                        }
                    }
                    
                    document.getElementById('modalTitle').innerHTML = 'Edytuj użytkownika';
                    openModal();
                })
                .catch(function(error) {
                    alert('Błąd: ' + error);
                });
        }
    }

    var deleteBtns = document.querySelectorAll('.deleteUserBtn');
    for (var i = 0; i < deleteBtns.length; i++) {
        deleteBtns[i].onclick = function() {
            var id = this.getAttribute('data-id');
            var name = this.getAttribute('data-name');
            
            if (confirm('Czy na pewno chcesz usunąć użytkownika ' + name + '?')) {
                var formData = new FormData();
                formData.append('id_uzytkownik', id);
                
                fetch('http://localhost/Dziennik_szkolny/amelia/public/index.php?action=adminDeleteUser', {
                    method: 'POST',
                    body: formData
                })
                .then(function(response) {
                    return response.json();
                })
                .then(function(data) {
                    if (data.error) {
                        alert(data.error);
                    } else if (data.success) {
                        alert(data.message);
                        location.reload();
                    }
                })
                .catch(function(error) {
                    alert('Błąd: ' + error);
                });
            }
        }
    }

    var roleCheckboxes = document.querySelectorAll('.roles-container input[type="checkbox"]');
    for (var i = 0; i < roleCheckboxes.length; i++) {
        roleCheckboxes[i].addEventListener('change', function() {
            if (this.checked) {
                this.parentNode.classList.add('checked');
            } else {
                this.parentNode.classList.remove('checked');
            }
        });
    }
});
</script>

</body>
</html>