<!DOCTYPE HTML>
<html>
<head>
    <title>Panel Ucznia - Dziennik szkolny</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="http://localhost/Dziennik_szkolny/assets/css/main.css" />
</head>
<body class="is-preload">

<div id="wrapper">
    <div id="sidebar">
        <div class="inner">
            <nav id="menu">
                <header class="major">
                    <h2>Przedmioty</h2>
                </header>
                <ul id="subjects-list">
                    <li><a href="#" data-subject-id="" class="subject-link">Wybierz przedmiot</a></li>
                    {foreach $subjects as $s}
                    <li>
                        <a href="#" data-subject-id="{$s.id_przedmiot}" data-subject-name="{$s.nazwa}" class="subject-link">
                            {$s.nazwa}
                        </a>
                    </li>
                    {foreachelse}
                    <li><a href="#">Brak przedmiotów</a></li>
                    {/foreach}
                </ul>
            </nav>
            
            <section>
                <header class="major">
                    <h2>Informacje o profilu</h2>
                </header>
                <div class="mini-posts">
                    <article>
                        <p><strong>Rola:</strong> {$user_role_display}</p>
                        <p><strong>Imię i nazwisko:</strong> {$user_name}</p>
                        <p><strong>Email:</strong> {$user_email}</p>
                        <p><strong>Klasa:</strong> {$class_name}</p>
                        <p><strong>Wychowawca:</strong> {$homeroom_teacher}</p>
                    </article>
                </div>
            </section>
            
            <footer id="footer">
                <p>Zalogowany jako: {$user_name}</p>
                <a href="http://localhost/Dziennik_szkolny/amelia/public/index.php?action=logout" class="button primary fit">Wyloguj się</a>
            </footer>
        </div>
    </div>

    <div id="main">
        <div class="inner">
            <header id="header">
                <a href="#" class="logo"><strong>Dziennik szkolny</strong> - Panel Ucznia</a>
            </header>
            
            <section>
                <header class="main">
                    <h1>Moje oceny</h1>
                </header>
                
                <div id="grades-container">
                    <div class="box">
                        <p><strong>To jest dziennik ocen.</strong> Aby zobaczyć oceny, wybierz przedmiot z panelu po lewej stronie.</p>
                    </div>
                </div>
                
            </section>
        </div>
    </div>
</div>

<script src="http://localhost/Dziennik_szkolny/assets/js/jquery.min.js"></script>
<script src="http://localhost/Dziennik_szkolny/assets/js/browser.min.js"></script>
<script src="http://localhost/Dziennik_szkolny/assets/js/breakpoints.min.js"></script>
<script src="http://localhost/Dziennik_szkolny/assets/js/util.js"></script>
<script src="http://localhost/Dziennik_szkolny/assets/js/main.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var subjectLinks = document.querySelectorAll('.subject-link');
    var gradesContainer = document.getElementById('grades-container');
    var actionUrl = 'http://localhost/Dziennik_szkolny/amelia/public/index.php?action=getGradesAjax&subject_id=';
    var sidebar = document.getElementById('sidebar');
    
    function hideSidebarOnMobile() {
        if (window.innerWidth <= 1280) {
            if (sidebar && !sidebar.classList.contains('inactive')) {
                sidebar.classList.add('inactive');
            }
        }
    }
    
    function loadGrades(subjectId, subjectName) {
        if (!subjectId) {
            gradesContainer.innerHTML = '<div class="box"><p><strong>To jest dziennik ocen.</strong> Aby zobaczyć oceny, wybierz przedmiot z panelu po lewej stronie.</p></div>';
            return;
        }
        
        gradesContainer.innerHTML = '<div class="box"><p>Ładowanie ocen...</p></div>';
        
        fetch(actionUrl + subjectId)
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                if (data.error) {
                    gradesContainer.innerHTML = '<div class="box"><p>' + data.error + '</p></div>';
                    return;
                }
                
                var gradesHtml = '<h3>Przedmiot: ' + data.subject_name + '</h3>';
                gradesHtml += '<div class="table-wrapper">';
                gradesHtml += '<table class="alt">';
                gradesHtml += '<thead>';
                gradesHtml += '<tr>';
                gradesHtml += '<th>Ocena</th>';
                gradesHtml += '<th>Waga</th>';
                gradesHtml += '<th>Data wystawienia</th>';
                gradesHtml += '<th>Nauczyciel</th>';
                gradesHtml += '<th>Opis</th>';
                gradesHtml += '</tr>';
                gradesHtml += '</thead>';
                gradesHtml += '<tbody>';
                
                if (data.grades.length === 0) {
                    gradesHtml += '<tr>';
                    gradesHtml += '<td colspan="5">Brak ocen z tego przedmiotu</td>';
                    gradesHtml += '</tr>';
                } else {
                    for (var i = 0; i < data.grades.length; i++) {
                        var grade = data.grades[i];
                        gradesHtml += '<tr>';
                        gradesHtml += '<td><strong>' + grade.wartosc + '</strong></td>';
                        gradesHtml += '<td>' + grade.waga + '</td>';
                        gradesHtml += '<td>' + grade.data_wystawienia + '</td>';
                        gradesHtml += '<td>' + grade.nauczyciel + '</td>';
                        gradesHtml += '<td>' + (grade.opis || '-') + '</td>';
                        gradesHtml += '</tr>';
                    }
                }
                
                gradesHtml += '</tbody>';
                gradesHtml += '</table>';
                gradesHtml += '</div>';
                
                if (data.arithmetic_average || data.weighted_average) {
                    gradesHtml += '<div style="background-color: #e8f5e9; border: 1px solid #4caf50; border-radius: 8px; padding: 1.5em; margin-top: 2em;">';
                    gradesHtml += '<h3 style="margin-top: 0; color: #2e7d32;">Podsumowanie</h3>';
                    gradesHtml += '<p><strong>Średnia arytmetyczna:</strong> ' + data.arithmetic_average + '</p>';
                    gradesHtml += '<p><strong>Średnia ważona:</strong> ' + data.weighted_average + '</p>';
                    gradesHtml += '</div>';
                }
                
                gradesContainer.innerHTML = gradesHtml;
                
                hideSidebarOnMobile();
            })
            .catch(function(error) {
                gradesContainer.innerHTML = '<div class="box"><p>Wystąpił błąd podczas ładowania ocen.</p></div>';
                console.error('Error:', error);
            });
    }
    
    for (var i = 0; i < subjectLinks.length; i++) {
        var link = subjectLinks[i];
        link.addEventListener('click', function(e) {
            e.preventDefault();
            var subjectId = this.getAttribute('data-subject-id');
            var subjectName = this.textContent;
            
            for (var j = 0; j < subjectLinks.length; j++) {
                subjectLinks[j].classList.remove('active');
            }
            this.classList.add('active');
            
            loadGrades(subjectId, subjectName);
        });
    }
});
</script>

</body>
</html>