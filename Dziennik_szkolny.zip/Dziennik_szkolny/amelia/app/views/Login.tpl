<!DOCTYPE HTML>
<html>
<head>
    <title>Logowanie - Dziennik szkolny</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="http://localhost/Dziennik_szkolny/assets/css/main.css" />
</head>
<body class="is-preload">

<div id="wrapper">
    <div id="main">
        <div class="inner">
            
            <header id="header">
                <a href="#" class="logo"><strong>Dziennik szkolny</strong> - logowanie</a>
            </header>
            
            <section>
                <header class="main">
                    <h1>Zaloguj się</h1>
                </header>
                
                {if $msgs->isError()}
                <div class="box" style="background-color: #faa; border-color: #f00;">
                    <h3>Wystąpiły błędy:</h3>
                    <ul>
                        {foreach $msgs->getMessages() as $msg}
                            {if $msg->isError()}
                                <li>{$msg->text}</li>
                            {/if}
                        {/foreach}
                    </ul>
                </div>
                {/if}
                
                {if $msgs->isInfo()}
                <div class="box" style="background-color: #afa; border-color: #0a0;">
                    <h3>Informacje:</h3>
                    <ul>
                        {foreach $msgs->getMessages() as $msg}
                            {if $msg->isInfo()}
                                <li>{$msg->text}</li>
                            {/if}
                        {/foreach}
                    </ul>
                </div>
                {/if}
                
                <form method="post" action="http://localhost/Dziennik_szkolny/amelia/public/index.php?action=login">
                    <div class="row gtr-uniform">
                        <div class="col-12">
                            <input type="text" name="login" id="login" value="{$form.login|default:''}" placeholder="Login" />
                        </div>
                        <div class="col-12">
                            <input type="password" name="pass" id="pass" placeholder="Hasło" />
                        </div>
                        <div class="col-12">
                            <ul class="actions">
                                <li><input type="submit" value="Zaloguj" class="primary" /></li>
                            </ul>
                        </div>
                    </div>
                </form>
                
            </section>
            
        </div>
    </div>
</div>

<script src="http://localhost/Dziennik_szkolny/assets/js/jquery.min.js"></script>
<script src="http://localhost/Dziennik_szkolny/assets/js/browser.min.js"></script>
<script src="http://localhost/Dziennik_szkolny/assets/js/breakpoints.min.js"></script>
<script src="http://localhost/Dziennik_szkolny/assets/js/util.js"></script>
<script src="http://localhost/Dziennik_szkolny/assets/js/main.js"></script>

</body>
</html>