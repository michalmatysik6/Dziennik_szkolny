<!DOCTYPE HTML>
<html>
<head>
    <title>Lista użytkowników</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="{$conf->app_root}/assets/css/main.css" />
</head>
<body class="is-preload">

<div id="wrapper">
    <div id="main">
        <div class="inner">
            
            <header id="header">
                <a href="#" class="logo"><strong>Dziennik szkolny</strong> - lista użytkowników</a>
            </header>
            
            <section>
                <header class="main">
                    <h1>Użytkownicy systemu</h1>
                </header>
                
                <div class="table-wrapper">
                    <table class="alt">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Login</th>
                                <th>Imię</th>
                                <th>Nazwisko</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Aktywny</th>
                            </tr>
                        </thead>
                        <tbody>
                            {foreach $users as $u}
                            <tr>
                                <td>{$u.id_uzytkownik}</td>
                                <td>{$u.login}</td>
                                <td>{$u.imie}</td>
                                <td>{$u.nazwisko}</td>
                                <td>{$u.email}</td>
                                <td>{$u.role|default:'brak'}</td>
                                <td>{if $u.aktywny}Tak{else}Nie{/if}</td>
                            </tr>
                            {foreachelse}
                            <tr>
                                <td colspan="7">Brak użytkowników w bazie</td>
                            </tr>
                            {/foreach}
                        </tbody>
                    </table>
                </div>
                
            </section>
            
        </div>
    </div>
</div>

<script src="{$conf->app_root}/assets/js/jquery.min.js"></script>
<script src="{$conf->app_root}/assets/js/browser.min.js"></script>
<script src="{$conf->app_root}/assets/js/breakpoints.min.js"></script>
<script src="{$conf->app_root}/assets/js/util.js"></script>
<script src="{$conf->app_root}/assets/js/main.js"></script>

</body>
</html>