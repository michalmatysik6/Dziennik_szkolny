<?php
header("Location: amelia/public/?action=login");
exit();